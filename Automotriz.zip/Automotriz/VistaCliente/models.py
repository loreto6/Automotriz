from django.db import models

# Create your models here.
class Marca(models.Model):
    nombre = models.CharField(max_length=50)
    def __str__(self):
        return str(self.nombre)

class Year(models.Model):
    year = models.IntegerField()
    def __str__(self):
        return str(self.year)

class Combustible(models.Model):
    nombre = models.CharField(max_length=50)
    def __str__(self):
        return str(self.nombre)
    
class Transmisión(models.Model):
    nombre = models.CharField(max_length=50)
    def __str__(self):
        return str(self.nombre)
 
class Auto(models.Model):
    imag = models.ImageField(upload_to='imagenesAutos/', blank=True, null=True)
    modelo = models.CharField(max_length=100)
    valor_inicial = models.IntegerField()
    combustible = models.ForeignKey(Combustible, on_delete=models.CASCADE)
    transmision = models.ForeignKey(Transmisión, on_delete=models.CASCADE)
    comentario = models.TextField(blank=True)
    kilometraje = models.IntegerField(blank=True, null=True)
    year = models.ForeignKey(Year, on_delete=models.CASCADE)
    marca = models.ForeignKey(Marca, on_delete=models.CASCADE)
    fecha = models.DateTimeField('Fecha')
    def __str__(self):
        return str(self.id)

class AutoImage(models.Model):
    auto = models.ForeignKey(Auto, related_name='images', on_delete=models.CASCADE)
    imagen = models.ImageField(upload_to='imagenesAutos/', blank=True, null=True)
    def __str__(self):
        return f"Image for Auto {self.auto.id}"

class Publicacion(models.Model):
    precio_venta = models.FloatField()
    disponiblidad= models.CharField(max_length=50, default='Activo') #Activo o Vendido
    id_auto = models.ForeignKey(Auto,on_delete=models.CASCADE)
    def __str__(self):
        return str(self.id)
    
class Cliente(models.Model):
    nombre = models.CharField(max_length=200)
    apellido = models.CharField(max_length=200)
    rut = models.CharField(max_length=200,unique=True)
    def __str__(self):
        return str(self.rut)

class Venta(models.Model):
    fecha = models.DateTimeField('Fecha')
    id_publicación = models.ForeignKey(Publicacion,on_delete=models.CASCADE)
    id_cliente = models.ForeignKey(Cliente,on_delete=models.CASCADE)
    
class Informe_Compra_Venta(models.Model):
    id_venta = models.ForeignKey(Venta,on_delete=models.CASCADE)
    id_auto = models.ForeignKey(Auto,on_delete=models.CASCADE)

class Contacto(models.Model):
    nombre = models.CharField(max_length=100)
    correo = models.EmailField()
    descripcion = models.TextField()
    id_publicación = models.ForeignKey(Publicacion,on_delete=models.CASCADE)
    def __str__(self):
        return str(self.id_publicación)